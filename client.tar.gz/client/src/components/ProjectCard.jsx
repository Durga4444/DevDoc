import { Link } from 'react-router-dom'
import { Calendar, Tag, FileText, Code, Link as LinkIcon } from 'lucide-react'

const ProjectCard = ({ project }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffTime = Math.abs(now - date)
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    
    if (diffDays === 1) return 'Today'
    if (diffDays === 2) return 'Yesterday'
    if (diffDays <= 7) return `${diffDays - 1} days ago`
    return date.toLocaleDateString()
  }

  return (
    <Link
      to={`/project/${project._id}`}
      className="group block"
    >
      <div className="card p-6 hover:shadow-lg hover:shadow-gray-200 dark:hover:shadow-gray-800 transition-all duration-300 hover:-translate-y-1 border-gray-200 dark:border-gray-700">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white truncate group-hover:text-primary-600 transition-colors duration-200">
              {project.name}
            </h3>
            {project.description && (
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 line-clamp-2 leading-relaxed">
                {project.description}
              </p>
            )}
          </div>
        </div>

        {/* Tags */}
        {project.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {project.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300 transition-colors duration-200 group-hover:bg-primary-50 group-hover:text-primary-700 dark:group-hover:bg-primary-900 dark:group-hover:text-primary-300"
              >
                <Tag size={12} className="mr-1" />
                {tag}
              </span>
            ))}
            {project.tags.length > 3 && (
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300">
                +{project.tags.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 pt-4 border-t border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <FileText size={14} className="mr-1.5" />
              <span className="font-medium">{project.notes ? '1' : '0'}</span>
            </div>
            <div className="flex items-center">
              <Code size={14} className="mr-1.5" />
              <span className="font-medium">{project.snippets?.length || 0}</span>
            </div>
            <div className="flex items-center">
              <LinkIcon size={14} className="mr-1.5" />
              <span className="font-medium">{project.links?.length || 0}</span>
            </div>
          </div>
          <div className="flex items-center text-xs">
            <Calendar size={12} className="mr-1" />
            <span className="hidden sm:inline">{formatDate(project.updatedAt)}</span>
            <span className="sm:hidden">{formatDate(project.updatedAt).split(' ')[0]}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default ProjectCard 