import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Filter } from 'lucide-react'
import { useProjects } from '../contexts/ProjectContext'
import ProjectCard from '../components/ProjectCard'
import EmptyState from '../components/EmptyState'

const Dashboard = () => {
  const { projects, loading, searchQuery } = useProjects()
  const [sortBy, setSortBy] = useState('updatedAt')
  const [sortOrder, setSortOrder] = useState('desc')
  const [filterTags, setFilterTags] = useState([])
  const [showFilters, setShowFilters] = useState(false)

  // Get all unique tags from projects
  const allTags = [...new Set(projects.flatMap(project => project.tags))].sort()

  // Filter and sort projects
  const filteredProjects = projects
    .filter(project => {
      if (filterTags.length === 0) return true
      return filterTags.some(tag => project.tags.includes(tag))
    })
    .sort((a, b) => {
      let aValue = a[sortBy]
      let bValue = b[sortBy]

      if (sortBy === 'updatedAt' || sortBy === 'createdAt') {
        aValue = new Date(aValue)
        bValue = new Date(bValue)
      }

      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1
      } else {
        return aValue < bValue ? 1 : -1
      }
    })

  const handleTagFilter = (tag) => {
    setFilterTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    )
  }

  const clearFilters = () => {
    setFilterTags([])
    setSortBy('updatedAt')
    setSortOrder('desc')
  }

  if (loading) {
    return (
      <div className="p-4 sm:p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-48 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 sm:p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex-1">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {searchQuery ? `Search Results for "${searchQuery}"` : 'My Projects'}
            </h1>
            <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">
              {filteredProjects.length} project{filteredProjects.length !== 1 ? 's' : ''}
              {searchQuery && ` found for "${searchQuery}"`}
            </p>
          </div>
          
          <div className="flex-shrink-0">
            <Link
              to="/create"
              className="btn-primary inline-flex items-center px-6 py-3 text-sm font-medium shadow-sm hover:shadow-md transition-all duration-200"
            >
              <Plus size={18} className="mr-2" />
              Create Project
            </Link>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-8">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              showFilters 
                ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            <Filter size={16} className="mr-2" />
            Filters
            {(filterTags.length > 0 || sortBy !== 'updatedAt' || sortOrder !== 'desc') && (
              <span className="ml-2 bg-primary-500 text-white text-xs rounded-full px-2 py-0.5">
                {filterTags.length + (sortBy !== 'updatedAt' ? 1 : 0) + (sortOrder !== 'desc' ? 1 : 0)}
              </span>
            )}
          </button>

          {(filterTags.length > 0 || sortBy !== 'updatedAt' || sortOrder !== 'desc') && (
            <button
              onClick={clearFilters}
              className="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 transition-colors"
            >
              Clear all
            </button>
          )}
        </div>

        {showFilters && (
          <div className="mt-4 p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Sort Options */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Sort by
                </label>
                <div className="flex flex-col sm:flex-row gap-3">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="input text-sm"
                  >
                    <option value="updatedAt">Last Updated</option>
                    <option value="createdAt">Created Date</option>
                    <option value="name">Name</option>
                  </select>
                  <select
                    value={sortOrder}
                    onChange={(e) => setSortOrder(e.target.value)}
                    className="input text-sm"
                  >
                    <option value="desc">Descending</option>
                    <option value="asc">Ascending</option>
                  </select>
                </div>
              </div>

              {/* Tag Filters */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                  Filter by tags
                </label>
                <div className="flex flex-wrap gap-2">
                  {allTags.map(tag => (
                    <button
                      key={tag}
                      onClick={() => handleTagFilter(tag)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                        filterTags.includes(tag)
                          ? 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300 shadow-sm'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Projects Grid */}
      {filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <ProjectCard key={project._id} project={project} />
          ))}
        </div>
      ) : (
        <EmptyState 
          title={searchQuery ? "No projects found" : "No projects yet"}
          description={searchQuery 
            ? `No projects match your search for "${searchQuery}"`
            : "Get started by creating your first project"
          }
          action={
            <Link to="/create" className="btn-primary px-6 py-3 text-sm font-medium">
              <Plus size={18} className="mr-2" />
              Create Project
            </Link>
          }
        />
      )}
    </div>
  )
}

export default Dashboard 